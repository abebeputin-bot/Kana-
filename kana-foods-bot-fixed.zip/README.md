# Kana Foods Telegram Bot (Webhook Ready)

This bot uses python-telegram-bot with webhook mode, ready for Render.

## Deploy to Render
1. Upload this repo or zip to Render.
2. Create a Worker service.
3. Set environment variable:
   - BOT_TOKEN = your telegram bot token
4. Start command: python bot.py
